<?php
require('../vista/eliminar_campania.php');
?>