<?php
require('../vista/eliminar_asesor.php');
?>