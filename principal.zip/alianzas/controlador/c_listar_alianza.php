<?php
require('../vista/listar_alianza.php');
?>