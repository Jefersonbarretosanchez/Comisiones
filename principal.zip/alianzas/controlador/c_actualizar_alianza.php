<?php
require('../vista/actualizar_alianza.php');
?>