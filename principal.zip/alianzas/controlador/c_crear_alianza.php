<?php
require('../vista/crear_alianza.php');
?>