<?php
require('../vista/eliminar_alianza.php');
?>