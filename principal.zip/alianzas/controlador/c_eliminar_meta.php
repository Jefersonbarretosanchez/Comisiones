<?php
require('../vista/eliminar_meta.php');
?>