<?php
require('../vista/eliminar_comision.php');
?>