<?php
require('../vista/actualizar_comision.php');
?>