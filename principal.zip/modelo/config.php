<?php
$con = mysqli_connect("localhost", "root", "", "comisiones");
?>