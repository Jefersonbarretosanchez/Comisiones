<footer>
      <div class="footer-container">
        <div class="content-foo">
          <h4>Ciudad de México -
            México</h4>
          <ul>
            <li>+55 01 3684-1404</li>
            <li>Calzada de Tlalpan</li>
            <li>#2148 Oficinas 8 y 9 –</li>
            <li>Segundo Piso Col.</li>
            <li>Campestre Churubusco</li>
            <li>Del. Coyoacán, CDMX.</li>
            <li>C.P. 04200 </li>
          </ul>
        </div>
        <div class="content-foo">
          <h4>Lima -
            Perú</h4>
          <ul>
            <li>+51 (01) 510-2125 Calle</li>
            <li>Coronel Inclán 235</li>
            <li>Oficina 501 – Miraflores</li>
          </ul>
        </div>
        <div class="content-foo">
          <h4>Bogotá -
            Colombia</h4>
          <ul>
            <li>Cra. 13 # 93-35</li>
          </ul>

          <!-- <a href="">Términos y Condiciones</a>
          <a href="">Quiénes Somos</a>
          <a href="">Libro de Reclamaciones</a>
          <a href="">Ayuda</a> -->
        </div>
        <div class="content-foo">
          <h4>Santiago -
            Chile</h4>
          <ul>
            <li>+56 22 594-0659</li>
            <li>Mariano Sánchez</li>
            <li>Fontecilla 310 Oficina</li>
            <li>02-137, Las Condes</li>
            <li>Acceso vía metro</li>
            <li>Estación Tobalaba</li>
          </ul>
        </div>
        <div class="content-foo">
          <h4>Quito -
            Ecuador</h4>
          <ul>
            <li>Av. 12 de Octubre N26-</li>
            <li>97 y Lincoln Ed. Torre</li>
            <li>1492 Piso 9 Ofic. 902</li>
            <!-- <li><i class="fas fa-headset"></i>+51 945 456 125</li> -->
          </ul>
        </div>
      </div>
      <div class="copyrigth">
        <h2><i class="far fa-copyright"></i> © 2023 Derechos Reservados</h2>
        <h3><a
            href="https://scalalearning.com/wp-content/uploads/2022/05/Politica-Cookies_SLearning_VF_19052022.pdf">Política
            de Cookies, Política de Privacidad y Aviso de Confidencialidad.</a></h3>
        <div class="redes-sociales">
          <div class="bubble">
            <a href="https://mx.linkedin.com/company/scalalearninglatam"><img src="imagenes/Linked-In.png"
                alt="Linkedin" width="50px"></a>
          </div>
          <div class="bubble">
            <a href="https://www.youtube.com/channel/UCTso-90g7wyYSj7suVKfghQ" "><img src="imagenes/You-Tube.png"
              alt="Youtube" width="50px"></a>
          </div>
          <div class="bubble">
            <a href="https://soundcloud.com/scalahed"><img src="imagenes/Spotify.png" alt="SoundCloud" width="50px"></a>
          </div>
          <div class="bubble">
            <a href="mailto:contacto@scalalearning.com"><img src="imagenes/Email.png" alt="Email" width="50px"></a>
          </div>
        </div>
    </footer>
